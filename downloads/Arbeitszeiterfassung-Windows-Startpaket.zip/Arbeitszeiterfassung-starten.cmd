@echo off
setlocal
title Arbeitszeiterfassung
set "AZ_APP_DIR=%~dp0"
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "$ErrorActionPreference = 'Stop'; $ProgressPreference = 'SilentlyContinue'; $root = $env:AZ_APP_DIR; $engine = Join-Path $root 'runtime-45.4.1-x64'; $exe = Join-Path $engine 'electron.exe'; $app = Join-Path $root 'app.asar'; try { if (!(Test-Path -LiteralPath $app -PathType Leaf)) { throw 'Bitte zuerst das gesamte ZIP entpacken.' }; if (!(Test-Path -LiteralPath $exe -PathType Leaf)) { $temp = Join-Path $root ('aze-download-' + [Guid]::NewGuid().ToString('N')); New-Item -ItemType Directory -Path $temp | Out-Null; try { $zip = Join-Path $temp 'electron-v45.4.1-win32-x64.zip'; $unpacked = Join-Path $temp 'entpackt'; Write-Host 'Erster Start: Die Laufzeit wird heruntergeladen (ca. 151 MB).'; Invoke-WebRequest -UseBasicParsing -TimeoutSec 600 -Uri 'https://github.com/electron/electron/releases/download/v45.4.1/electron-v45.4.1-win32-x64.zip' -OutFile $zip; if ((Get-FileHash -Algorithm SHA256 -LiteralPath $zip).Hash -ne '2ba6223afa9121f42831fefe92c434334907540165294fc56697449d12e7cfe9') { throw 'Die heruntergeladene Datei hat eine falsche Pruefsumme.' }; Expand-Archive -LiteralPath $zip -DestinationPath $unpacked; if (!(Test-Path -LiteralPath $engine)) { Move-Item -LiteralPath $unpacked -Destination $engine }; } finally { Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue }; }; $target = Join-Path $engine 'resources/app.asar'; if (!(Test-Path -LiteralPath $target) -or (Get-FileHash -LiteralPath $app).Hash -ne (Get-FileHash -LiteralPath $target).Hash) { Copy-Item -LiteralPath $app -Destination $target -Force; }; Start-Process -FilePath $exe -WorkingDirectory $engine; } catch { Write-Host $_.Exception.Message; exit 1 }"
if errorlevel 1 (
  echo Die App konnte nicht gestartet werden.
  pause
  exit /b 1
)
